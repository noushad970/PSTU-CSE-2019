public class one_12 {
    public static void main(String[] args) {
        System.out.println(" Twinkle, twinkle, little star,");
        System.out.println("   How I wonder what you are!");
        System.out.println("       Up above the world so high,");
        System.out.println("       Like a diamond in the sky.");
        System.out.println("Twinkle, twinkle, little star,");
        System.out.println("   How I wonder what you are");
    }
}
