import java.util.Scanner;

public class one_11 {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the password: ");
        String password=s.nextLine();
        System.out.println("The password was : "+password);

    }
}
