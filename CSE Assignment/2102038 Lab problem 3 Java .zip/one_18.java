import java.util.Scanner;

public class one_18 {
    public static void main(String[] args) {
        System.out.println("Enter the number: ");
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();

        if(n%2==0)
        System.out.println("1");
        
        else
        System.out.println("0");
    }
}
