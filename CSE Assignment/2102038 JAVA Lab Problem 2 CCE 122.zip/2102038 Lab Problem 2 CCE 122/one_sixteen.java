class one_sixteen{
    public static void main(String[] args) {
        
        int a=Integer.parseInt("10",2);
        int b=Integer.parseInt("11",2);
        int c=a+b;
        String z=Integer.toBinaryString(c);
        System.out.println(z);
        

    }
}