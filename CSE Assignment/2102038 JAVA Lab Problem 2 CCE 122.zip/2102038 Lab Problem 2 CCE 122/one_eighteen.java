class one_eighteen{
    public static void main(String[] args) {
        
        int n=15;
        String x=Integer.toHexString(n);
        System.out.println(x);
        

    }
}