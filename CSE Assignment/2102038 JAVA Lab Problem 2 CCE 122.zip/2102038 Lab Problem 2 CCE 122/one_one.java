public class one_one {
    public static void main(String[] args) {
        System.out.println("Hello");
        System.out.println("My name is Noushad");
    }
}
