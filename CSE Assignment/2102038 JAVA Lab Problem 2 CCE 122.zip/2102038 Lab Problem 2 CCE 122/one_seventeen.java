import java.util.Scanner;
public class one_seventeen {
    public static void main(String[] args) {
     
        
        int x=Integer.parseInt("10",2);
        int y=Integer.parseInt("11",2);
        int z=x*y;
        String ans=Integer.toBinaryString(z);
        System.out.println(ans);
        



    }
}
