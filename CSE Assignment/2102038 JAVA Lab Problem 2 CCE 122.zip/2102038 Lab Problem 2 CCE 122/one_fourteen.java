import java.util.Scanner;
public class one_fourteen {
    public static void main(String[] args) {
       int temp,a=10,b=20;
       System.out.println("Before swap a= "+a+" b= "+b);
       temp=a;
       a=b;
       b=temp;
       System.out.println("After swap a= "+a+" b= "+b);


        


    }
}
