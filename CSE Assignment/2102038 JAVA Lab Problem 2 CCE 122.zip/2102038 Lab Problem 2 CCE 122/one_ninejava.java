import java.util.Scanner;
public class one_ninejava {
    public static void main(String[] args) {
        double d=((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5));
        System.out.println(d);
        
    }
}
