public class one_two {
    public static void main(String[] args) {
        int a=121,b=123;
        int c=a+b;
        System.out.println("The sum of a and b is: "+c);
    }
}
