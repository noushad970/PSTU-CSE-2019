public class one_four {
    public static void main(String[] args) {
        int a= -5 + 8 * 6;
        int b =(55+9) % 9;
        int c= 20 + -3*5 / 8;
        int d= 5 + 15 / 3 * 2 - 8 % 3;
        System.out.println("The value of First operation is: "+a);
        System.out.println("The value of Second operation is: "+b);
        System.out.println("The value of Third operation is: "+c);
        System.out.println("The value of Fourth operation is: "+d);
    }
}
