import java.util.Scanner;
public class one_five {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter A: ");
        int a=s.nextInt();
        
        System.out.println("Enter B: ");
        int b=s.nextInt();
        int mul=a*b;
        System.out.println("The production of A and B: "+mul);
        
    }
}
