import java.util.Scanner;
public class one_six {
    public static void main(String[] args) {
        int a=125,b=24;
        int c=a+b;
        int d=a-b;
        int e=a*b;
        int f=a/b;
        int g=a%b;
        System.out.println(c);
        System.out.println(d);
        System.out.println(e);
        System.out.println(f);
        System.out.println(g);
        
    }
}
