public class one_three {
    public static void main(String[] args) {
        int a=121,b=15;
        int c=a/b;
        System.out.println("The division of a devided by b is: "+c);
    }
}
