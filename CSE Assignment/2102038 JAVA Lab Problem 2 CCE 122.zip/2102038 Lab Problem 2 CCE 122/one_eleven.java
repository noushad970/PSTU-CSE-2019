import java.util.Scanner;
public class one_eleven {
    public static void main(String[] args) {
        double radius= 7;
        double pai=3.1416d;
        double peremeter=2*radius*pai;
        double area=pai*radius*radius;
        System.out.println("The perimeter is: "+peremeter);
        System.out.println("The Area is : "+area);
        
    }
}
