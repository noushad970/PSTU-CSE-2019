public class eight_28 {
    //repeat code
}
