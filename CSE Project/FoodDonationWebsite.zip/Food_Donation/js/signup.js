function toggleOrgFields(show) {
    document.getElementById('organizationFields').style.display = show ? 'block' : 'none';
  }
  